const tokenfile = require('./tokenfile.json');
const botconfig = require('./botconfig.json');
const { REST, Routes } = require('discord.js');

const rest = new REST({version: '10'}).setToken(tokenfile.token);

const commands = [
    {
        name:"test",
        description:"Basic test command."
    }
];

(async () => {
    try {
        console.log("Registering commands...");

        await rest.put(
            Routes.applicationGuildCommands(
                botconfig.client_id,
                botconfig.guild_id
            ),
            { body: commands }
        )
        console.log("Successfully registered!");
    } catch (error) {
        console.log(`Something went wrong: ${error}`);
    }
})();