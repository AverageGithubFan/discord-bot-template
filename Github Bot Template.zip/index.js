const tokenfile = require('./tokenfile.json');
const { Client, IntentsBitField, ActivityType } = require('discord.js');

//turn on intents on the developer portal
const bot = new Client({
    intents:[
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.GuildMessageReactions,
        IntentsBitField.Flags.MessageContent
    ]
});

//join message
bot.on("guildMemberAdd", member =>{
    const channelID = "channel-id"; //Discord->settings->Advanced->Developer Mode->On; And then right click on the channel.

    console.log(member)

    const channel = member.guild.channels.cache.get(channelID);

    const msg = `**Welcome to the server, <@${member.id}>!**`;

    member.roles.add("role id here");
    //make sure that the member rank is below the bot's rank

    channel.send(msg)
})

//leave message
bot.on("guildMemberRemove", member =>{
    const channelID = "channel-id";

    console.log(member)

    const channel = member.guild.channels.cache.get(channelID);

    const msg = `**<@${member.id}> has left the server.**`;

    channel.send(msg)
})

bot.on("ready", (c) => {
    console.log(`${c.user.tag} turned online on ${c.guilds.cache.size} servers!`); // character output to the console when the bot turns online

    bot.user.setActivity({
        name:"Under development.", // the activity to be displayed
        type: ActivityType.Playing // activity type
    })

    bot.user.setStatus("online"); //change the status: dnd, online, idle, offline
});

bot.on("interactionCreate", async (interaction) =>{ //make sure that you ran "register-commands.js"
    if(!interaction.isChatInputCommand()) return;
    if (interaction.commandName === "test") {
        return interaction.reply("Command working!");
    }
});

bot.login(tokenfile.token); // tokenfile.json -> "token":"your-token"